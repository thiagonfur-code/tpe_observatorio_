# Observatório de Indicadores Econômicos da Paraíba

**Disciplina:** Técnicas de Pesquisa e Análise Econômica II (TPAE II) — Turma 01, 2026.2  
**Demandante:** Conselho Regional de Economia da Paraíba (Corecon-PB)  
**Equipe:** Thiago Nicácio, Carlos Victor e Riã Monteiro  
**Professor:** Alessio Tony

## Apresentação
O projeto propõe organizar e apresentar um conjunto inicial de indicadores econômicos da Paraíba, usando fontes públicas oficiais e informando definições, períodos, recortes territoriais e limitações. A proposta é servir como porta de entrada para as fontes originais, sem substituí-las.

## Pergunta de pesquisa
Como organizar e apresentar um conjunto inicial de indicadores econômicos da Paraíba, com fontes oficiais e recortes territoriais claros, de modo a facilitar o acesso e a compreensão dessas informações pelo Corecon-PB e por seus públicos?

## Escopo inicial
As dimensões prioritárias são atividade econômica, mercado de trabalho, renda e contexto demográfico. Os indicadores listados são candidatos: a inclusão final depende de disponibilidade, documentação, comparabilidade e prazo da disciplina. Não se pretende fazer inferência causal ou previsão econômica.

## Estrutura do repositório
- `data/raw/`: cópias originais permitidas, sem alterações.
- `data/processed/`: arquivos tratados, com procedimento documentado.
- `notebooks/`: scripts/notebooks de aquisição, tratamento e análise.
- `docs/`: plano de pesquisa, inventário, dicionário e memórias.
- `outputs/`: tabelas, gráficos e produtos finais.

## Fontes candidatas
- IBGE/SIDRA: https://sidra.ibge.gov.br/
- IBGE — Portal de Estatísticas: https://www.ibge.gov.br/estatisticas/
- IBGE — PIB dos Municípios: https://www.ibge.gov.br/estatisticas/economicas/contas-nacionais/9088-produto-interno-bruto-dos-municipios.html
- IBGE — Estimativas da População: https://www.ibge.gov.br/estatisticas/sociais/populacao/9103-estimativas-de-populacao.html
- IBGE — PNAD Contínua: https://www.ibge.gov.br/estatisticas/sociais/populacao/9171-pesquisa-nacional-por-amostra-de-domicilios-continua.html
- Ministério do Trabalho e Emprego/PDET: https://pdet.mte.gov.br/

## Como reproduzir a aquisição
1. Abrir o portal institucional indicado no inventário.
2. Selecionar a tabela/produto adequado e registrar o código/nome, filtros, unidade, recorte territorial e período.
3. Baixar o arquivo original para `data/raw/`, preservando o nome original quando possível.
4. Registrar a data de consulta e a versão/edição em `docs/registro_aquisicao.md`.
5. Executar o tratamento somente em cópia de trabalho e salvar a saída em `data/processed/`.
6. Conferir totais, unidades, valores ausentes e compatibilidade antes de gerar tabelas/gráficos.
7. Citar fonte e período em todo produto publicado.

**Importante:** os arquivos de dados ainda precisam ser selecionados e extraídos pelo grupo. Este README não afirma que a coleta ou a análise já foi concluída.

## Arquivos de documentação
- `docs/inventario_fontes.csv`: inventário inicial de fontes e limitações.
- `docs/dicionario_preliminar.csv`: variáveis candidatas e cuidados de interpretação.
- `docs/plano_aquisicao.md`: procedimento, frequência e responsabilidades.
- `docs/registro_aquisicao.md`: modelo para registrar cada download.
- `docs/entrega03_referencia.md`: resumo do escopo definido na Entrega 3.

## Segurança e versionamento
Não versionar senhas, tokens, chaves, dados pessoais, documentos internos ou bases restritas. Bases grandes ou com condições que impeçam redistribuição devem ser substituídas por instruções reproduzíveis de obtenção. Consultar os termos e a documentação da fonte específica antes de redistribuir arquivos.

## Repositório
https://github.com/thignicacio2003-cyber/tpe_observatorio
