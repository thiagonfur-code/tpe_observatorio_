# Controle inicial de tarefas

**Atenção:** os prazos abaixo são uma proposta interna de organização preparada em 29/10/2026, não prazos oficiais definidos pelo professor. A equipe deve confirmar ou ajustar as datas entre si e com o professor.

| Tarefa | Responsável sugerido | Prazo interno proposto | Situação |
|---|---|---|---|
| Atualizar README, estrutura de pastas e .gitignore no GitHub | Thiago Nicácio (coordenação) | 30/10/2026 | Pendente |
| Conferir inventário, URLs e condições de uso de cada fonte | Carlos Victor | 01/11/2026 | Pendente |
| Confirmar indicadores e recortes disponíveis nas bases oficiais | Riã Monteiro | 03/11/2026 | Pendente |
| Registrar downloads e parâmetros em registro_aquisicao.md | Responsáveis da fonte; revisar em conjunto | 05/11/2026 | Pendente |
| Revisar arquivos, acessibilidade do repositório e envio ao professor | Equipe completa | 06/11/2026 | Pendente |

As situações estão marcadas como **Pendente** porque não foi fornecida confirmação de execução. Atualizar este quadro conforme as tarefas forem concluídas.
