# data/processed

Armazenar aqui cópias tratadas. Documentar no notebook/script todas as transformações realizadas.
