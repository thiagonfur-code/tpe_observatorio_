# data/raw

Armazenar aqui arquivos originais obtidos nas fontes, sem alteração, respeitando condições de uso. Registrar cada aquisição em docs/registro_aquisicao.md.
