# Continuidade em relação à Entrega 3

A Entrega 3 definiu como tema o Painel/Observatório de Indicadores Econômicos da Paraíba, com o Corecon-PB como demandante. O problema central é a dificuldade prática de localizar, consultar e relacionar indicadores divulgados por diferentes instituições, com formatos, períodos e recortes distintos.

A pergunta principal é: como organizar e apresentar um conjunto inicial de indicadores econômicos da Paraíba, com fontes oficiais e recortes territoriais claros, para facilitar o acesso e a compreensão?

Dimensões candidatas: atividade econômica (PIB municipal e PIB per capita), mercado de trabalho (pessoas ocupadas e vínculos formais), renda e contexto demográfico (população). A seleção final deve respeitar a disponibilidade, a documentação e a comparabilidade de cada série.

O projeto tem caráter descritivo e exploratório. Não pretende produzir previsões, afirmar causalidade ou construir uma plataforma permanente com atualização automática.
