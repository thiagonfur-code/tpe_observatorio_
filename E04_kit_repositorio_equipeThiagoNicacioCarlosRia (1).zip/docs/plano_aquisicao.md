# Plano de aquisição dos dados

**Projeto:** Observatório de Indicadores Econômicos da Paraíba  
**Equipe:** Thiago Nicácio, Carlos Victor e Riã Monteiro  
**Data de preparação do plano:** 29/10/2026

Este documento descreve procedimentos previstos. A data de consulta do inventário registra a verificação dos portais, não significa que todos os arquivos tenham sido baixados ou que as séries finais já tenham sido escolhidas.

| Fonte/produto candidato | Método de obtenção | Arquivo/endpoint | Frequência de atualização | Parâmetros a registrar | Responsável sugerido | Prazo/etapa |
|---|---|---|---|---|---|---|
| IBGE/SIDRA — PIB municipal | Consulta da tabela no SIDRA e exportação disponibilizada pelo portal; API apenas se necessária e documentada | Registrar código da tabela, variável e filtros efetivamente escolhidos | Anual, conforme divulgação do produto | PB/municípios, anos disponíveis, variável, unidade, preços correntes e versão | Thiago Nicácio — coordenação do registro | Na etapa de seleção e coleta |
| IBGE — Estimativas da População | Baixar tabela/arquivo da edição escolhida no portal institucional | Registrar nome exato do arquivo e edição/ano | Anual | Municípios/UF, data de referência, edição e tipo de estimativa | Carlos Victor — conferência de cobertura | Na etapa de seleção e coleta |
| IBGE — PNAD Contínua | Consultar tabela/publicação e baixar produto oficial adequado ao indicador | Registrar tabela, arquivo, trimestre/ano e indicador | Conforme divulgação do indicador (trimestral/anual ou outra periodicidade oficial) | Indicador, conceito de rendimento/ocupação, unidade, período e nível geográfico | Riã Monteiro — conferência conceitual | Após verificar disponibilidade estadual |
| MTE/PDET — RAIS ou Novo Caged | Selecionar o produto adequado e obter arquivo/documentação pelo portal | Registrar produto, nome do arquivo e competência | RAIS normalmente anual; Novo Caged mensal, conforme produto e calendário oficial | Município/UF, competência, variável e conceito de estoque/fluxo | A definir em reunião do grupo | Após confirmar o produto mais adequado |

## Procedimento comum
1. Conferir se a fonte é institucional e se a tabela mede o conceito pretendido.
2. Registrar data de acesso, título, código da tabela ou nome do arquivo, filtros, período, recorte territorial, unidade e observações.
3. Guardar o arquivo original em `data/raw/` somente quando as condições de uso permitirem.
4. Não sobrescrever o arquivo original; tratamentos devem gerar arquivos separados em `data/processed/`.
5. Documentar cada transformação em notebook/script, incluindo variáveis removidas, filtros, conversões de unidade e tratamento de ausências.
6. Validar totais e consistência com a fonte. Quando houver divergência, registrar a ocorrência em vez de ajustar sem justificativa.
7. Atualizar os dados quando uma nova edição oficial for publicada e necessária ao projeto; registrar a nova data e versão.
8. Não preencher lacunas com estimativas próprias sem orientação expressa do professor.

## Observações
- A escolha definitiva das séries ainda depende de avaliação de cobertura e comparabilidade.
- A PNAD Contínua é uma pesquisa amostral; a disponibilidade e a precisão variam conforme indicador e recorte.
- RAIS e Novo Caged têm conceitos e finalidades diferentes. Não combinar estoque de vínculos com fluxos de admissões/desligamentos como se fossem a mesma medida.
- As condições de uso/licença devem ser verificadas para cada produto antes de redistribuir os dados.
- Os responsáveis acima são uma divisão inicial sugerida para organizar o trabalho; o grupo pode ajustá-la.
