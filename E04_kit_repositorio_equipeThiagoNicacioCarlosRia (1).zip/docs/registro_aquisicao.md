# Registro de aquisição — preencher a cada coleta

| Campo | Registro |
|---|---|
| Fonte/instituição | |
| Título/código da tabela ou nome do arquivo | |
| URL exata do produto consultado | |
| Data e hora de acesso | |
| Período de referência | |
| Cobertura geográfica | |
| Variáveis/filtros selecionados | |
| Unidade de medida | |
| Formato do arquivo | |
| Edição/versão | |
| Condições de uso/licença consultadas | |
| Caminho salvo em `data/raw/` | |
| Responsável pela coleta | |
| Conferências realizadas | |
| Limitações/observações | |
