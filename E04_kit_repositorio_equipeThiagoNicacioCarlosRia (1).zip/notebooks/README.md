# notebooks

Guardar scripts/notebooks de aquisição, tratamento e análise, com parâmetros e etapas reproduzíveis.
