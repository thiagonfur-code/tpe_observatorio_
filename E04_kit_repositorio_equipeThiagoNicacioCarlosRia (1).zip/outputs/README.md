# outputs

Guardar tabelas, gráficos e produtos finais, com fonte, período e unidade claramente indicados.
